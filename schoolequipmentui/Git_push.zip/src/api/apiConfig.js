// // Toggle between "mock" and "real" depending on the environment
// const USE_MOCK = true; // 👈 change to false when .NET backend is ready

// import * as mockApi from "./mockApi.js";
// import * as realApi from "./realApi.js";

// export const api = USE_MOCK ? mockApi : realApi;
